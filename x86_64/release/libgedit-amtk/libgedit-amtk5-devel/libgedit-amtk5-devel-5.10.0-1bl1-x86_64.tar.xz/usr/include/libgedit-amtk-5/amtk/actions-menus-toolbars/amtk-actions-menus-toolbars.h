/* SPDX-FileCopyrightText: 2026 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (AMTK_H_INSIDE) && !defined (AMTK_COMPILATION)
#error "Only <amtk/amtk.h> can be included directly."
#endif

#include <amtk/actions-menus-toolbars/amtk-actions-menus-toolbars-enum-types.h>

#include <amtk/actions-menus-toolbars/amtk-action-info.h>
#include <amtk/actions-menus-toolbars/amtk-action-info-store.h>
#include <amtk/actions-menus-toolbars/amtk-action-info-central-store.h>
#include <amtk/actions-menus-toolbars/amtk-action-map.h>
#include <amtk/actions-menus-toolbars/amtk-application-window.h>
#include <amtk/actions-menus-toolbars/amtk-factory.h>
#include <amtk/actions-menus-toolbars/amtk-gmenu.h>
#include <amtk/actions-menus-toolbars/amtk-menu-item.h>
#include <amtk/actions-menus-toolbars/amtk-menu-shell.h>
#include <amtk/actions-menus-toolbars/amtk-shortcuts.h>
#include <amtk/actions-menus-toolbars/amtk-utils.h>
