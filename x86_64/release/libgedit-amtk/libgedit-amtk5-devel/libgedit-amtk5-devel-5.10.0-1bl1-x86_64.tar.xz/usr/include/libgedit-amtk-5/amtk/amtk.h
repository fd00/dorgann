/* SPDX-FileCopyrightText: 2017-2026 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#define AMTK_H_INSIDE

#include <amtk/amtk-init.h>
#include <amtk/actions-menus-toolbars/amtk-actions-menus-toolbars.h>
#include <amtk/amtk-tree-view-scrolled-window-sizing.h>

#undef AMTK_H_INSIDE
