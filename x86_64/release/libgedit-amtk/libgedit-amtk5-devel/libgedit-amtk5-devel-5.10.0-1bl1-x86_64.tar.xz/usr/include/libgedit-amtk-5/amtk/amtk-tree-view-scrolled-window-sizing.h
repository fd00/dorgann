/* SPDX-FileCopyrightText: 2026 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (AMTK_H_INSIDE) && !defined (AMTK_COMPILATION)
#error "Only <amtk/amtk.h> can be included directly."
#endif

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define AMTK_TYPE_TREE_VIEW_SCROLLED_WINDOW_SIZING             (amtk_tree_view_scrolled_window_sizing_get_type ())
#define AMTK_TREE_VIEW_SCROLLED_WINDOW_SIZING(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), AMTK_TYPE_TREE_VIEW_SCROLLED_WINDOW_SIZING, AmtkTreeViewScrolledWindowSizing))
#define AMTK_TREE_VIEW_SCROLLED_WINDOW_SIZING_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), AMTK_TYPE_TREE_VIEW_SCROLLED_WINDOW_SIZING, AmtkTreeViewScrolledWindowSizingClass))
#define AMTK_IS_TREE_VIEW_SCROLLED_WINDOW_SIZING(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), AMTK_TYPE_TREE_VIEW_SCROLLED_WINDOW_SIZING))
#define AMTK_IS_TREE_VIEW_SCROLLED_WINDOW_SIZING_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), AMTK_TYPE_TREE_VIEW_SCROLLED_WINDOW_SIZING))
#define AMTK_TREE_VIEW_SCROLLED_WINDOW_SIZING_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), AMTK_TYPE_TREE_VIEW_SCROLLED_WINDOW_SIZING, AmtkTreeViewScrolledWindowSizingClass))

typedef struct _AmtkTreeViewScrolledWindowSizing         AmtkTreeViewScrolledWindowSizing;
typedef struct _AmtkTreeViewScrolledWindowSizingClass    AmtkTreeViewScrolledWindowSizingClass;
typedef struct _AmtkTreeViewScrolledWindowSizingPrivate  AmtkTreeViewScrolledWindowSizingPrivate;

struct _AmtkTreeViewScrolledWindowSizing
{
	GtkScrolledWindow parent;
	AmtkTreeViewScrolledWindowSizingPrivate *priv;
};

struct _AmtkTreeViewScrolledWindowSizingClass
{
	GtkScrolledWindowClass parent_class;
	gpointer padding[1];
};

G_MODULE_EXPORT
GType		amtk_tree_view_scrolled_window_sizing_get_type			(void) G_GNUC_CONST;

G_MODULE_EXPORT
AmtkTreeViewScrolledWindowSizing *
		amtk_tree_view_scrolled_window_sizing_new			(void);

G_MODULE_EXPORT
GtkTreeView *	amtk_tree_view_scrolled_window_sizing_get_tree_view		(AmtkTreeViewScrolledWindowSizing *self);

G_MODULE_EXPORT
gboolean	amtk_tree_view_scrolled_window_sizing_get_monitor_limit		(AmtkTreeViewScrolledWindowSizing *self);

G_MODULE_EXPORT
void		amtk_tree_view_scrolled_window_sizing_set_monitor_limit		(AmtkTreeViewScrolledWindowSizing *self,
										 gboolean                          monitor_limit);

G_END_DECLS
