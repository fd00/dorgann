libgedit-amtk
=============

Short description
-----------------

Gedit Technology - The Good Morning Toolkit

Longer description
------------------

libgedit-amtk is part of Gedit Technology.

It is a library that extends GTK at the exception of GtkTextView which is
extended by libgedit-gtksourceview.

Amtk initially was the acronym for “Actions, Menus and Toolbars Kit”. It
provides a basic GtkUIManager replacement based on GAction that is suitable for
both a traditional UI or a modern UI with a GtkHeaderBar.

More information
----------------

libgedit-amtk currently targets **GTK 3**.

[More information about libgedit-amtk](docs/more-information.md).
