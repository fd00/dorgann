#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libfyaml::fyaml" for configuration "RelWithDebInfo"
set_property(TARGET libfyaml::fyaml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libfyaml::fyaml PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libfyaml.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygfyaml-0.dll"
  )

list(APPEND _cmake_import_check_targets libfyaml::fyaml )
list(APPEND _cmake_import_check_files_for_libfyaml::fyaml "${_IMPORT_PREFIX}/lib/libfyaml.dll.a" "${_IMPORT_PREFIX}/bin/cygfyaml-0.dll" )

# Import target "libfyaml::fy-tool" for configuration "RelWithDebInfo"
set_property(TARGET libfyaml::fy-tool APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libfyaml::fy-tool PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/fy-tool.exe"
  )

list(APPEND _cmake_import_check_targets libfyaml::fy-tool )
list(APPEND _cmake_import_check_files_for_libfyaml::fy-tool "${_IMPORT_PREFIX}/bin/fy-tool.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
