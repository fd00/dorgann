#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hdr_histogram::hdr_histogram" for configuration "RelWithDebInfo"
set_property(TARGET hdr_histogram::hdr_histogram APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(hdr_histogram::hdr_histogram PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libhdr_histogram.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyghdr_histogram-6.dll"
  )

list(APPEND _cmake_import_check_targets hdr_histogram::hdr_histogram )
list(APPEND _cmake_import_check_files_for_hdr_histogram::hdr_histogram "${_IMPORT_PREFIX}/lib/libhdr_histogram.dll.a" "${_IMPORT_PREFIX}/bin/cyghdr_histogram-6.dll" )

# Import target "hdr_histogram::hdr_decoder" for configuration "RelWithDebInfo"
set_property(TARGET hdr_histogram::hdr_decoder APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(hdr_histogram::hdr_decoder PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/hdr_decoder.exe"
  )

list(APPEND _cmake_import_check_targets hdr_histogram::hdr_decoder )
list(APPEND _cmake_import_check_files_for_hdr_histogram::hdr_decoder "${_IMPORT_PREFIX}/bin/hdr_decoder.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
