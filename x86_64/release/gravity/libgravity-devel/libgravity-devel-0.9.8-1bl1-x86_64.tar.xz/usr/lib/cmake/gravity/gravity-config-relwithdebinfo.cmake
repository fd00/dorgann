#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "gravity::gravityapi" for configuration "RelWithDebInfo"
set_property(TARGET gravity::gravityapi APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(gravity::gravityapi PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libgravityapi.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyggravityapi-0.dll"
  )

list(APPEND _cmake_import_check_targets gravity::gravityapi )
list(APPEND _cmake_import_check_files_for_gravity::gravityapi "${_IMPORT_PREFIX}/lib/libgravityapi.dll.a" "${_IMPORT_PREFIX}/bin/cyggravityapi-0.dll" )

# Import target "gravity::gravity" for configuration "RelWithDebInfo"
set_property(TARGET gravity::gravity APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(gravity::gravity PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/gravity.exe"
  )

list(APPEND _cmake_import_check_targets gravity::gravity )
list(APPEND _cmake_import_check_files_for_gravity::gravity "${_IMPORT_PREFIX}/bin/gravity.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
