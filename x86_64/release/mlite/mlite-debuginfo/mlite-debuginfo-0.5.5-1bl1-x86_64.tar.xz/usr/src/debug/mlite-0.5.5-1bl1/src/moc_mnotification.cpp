/****************************************************************************
** Meta object code from reading C++ file 'mnotification.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../src/mlite-0.5.5/src/mnotification.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mnotification.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MNotification_t {
    QByteArrayData data[6];
    char stringdata0[50];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MNotification_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MNotification_t qt_meta_stringdata_MNotification = {
    {
QT_MOC_LITERAL(0, 0, 13), // "MNotification"
QT_MOC_LITERAL(1, 14, 7), // "summary"
QT_MOC_LITERAL(2, 22, 4), // "body"
QT_MOC_LITERAL(3, 27, 5), // "image"
QT_MOC_LITERAL(4, 33, 5), // "count"
QT_MOC_LITERAL(5, 39, 10) // "identifier"

    },
    "MNotification\0summary\0body\0image\0count\0"
    "identifier"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MNotification[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       5,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QString, 0x00095103,
       2, QMetaType::QString, 0x00095103,
       3, QMetaType::QString, 0x00095103,
       4, QMetaType::UInt, 0x00095103,
       5, QMetaType::QString, 0x00095103,

       0        // eod
};

void MNotification::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        MNotification *_t = static_cast<MNotification *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->summary(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->body(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->image(); break;
        case 3: *reinterpret_cast< uint*>(_v) = _t->count(); break;
        case 4: *reinterpret_cast< QString*>(_v) = _t->identifier(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        MNotification *_t = static_cast<MNotification *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setSummary(*reinterpret_cast< QString*>(_v)); break;
        case 1: _t->setBody(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setImage(*reinterpret_cast< QString*>(_v)); break;
        case 3: _t->setCount(*reinterpret_cast< uint*>(_v)); break;
        case 4: _t->setIdentifier(*reinterpret_cast< QString*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject MNotification::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_MNotification.data,
      qt_meta_data_MNotification,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MNotification::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MNotification::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MNotification.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int MNotification::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
