/****************************************************************************
** Meta object code from reading C++ file 'mnotificationmanagerproxy.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../src/mlite-0.5.5/src/mnotificationmanagerproxy.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mnotificationmanagerproxy.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MNotificationManagerProxy_t {
    QByteArrayData data[30];
    char stringdata0[448];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MNotificationManagerProxy_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MNotificationManagerProxy_t qt_meta_stringdata_MNotificationManagerProxy = {
    {
QT_MOC_LITERAL(0, 0, 25), // "MNotificationManagerProxy"
QT_MOC_LITERAL(1, 26, 13), // "ActionInvoked"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 2), // "id"
QT_MOC_LITERAL(4, 44, 10), // "action_key"
QT_MOC_LITERAL(5, 55, 18), // "NotificationClosed"
QT_MOC_LITERAL(6, 74, 6), // "reason"
QT_MOC_LITERAL(7, 81, 17), // "CloseNotification"
QT_MOC_LITERAL(8, 99, 19), // "QDBusPendingReply<>"
QT_MOC_LITERAL(9, 119, 15), // "GetCapabilities"
QT_MOC_LITERAL(10, 135, 30), // "QDBusPendingReply<QStringList>"
QT_MOC_LITERAL(11, 166, 16), // "GetNotifications"
QT_MOC_LITERAL(12, 183, 40), // "QDBusPendingReply<QList<MNoti..."
QT_MOC_LITERAL(13, 224, 8), // "app_name"
QT_MOC_LITERAL(14, 233, 20), // "GetServerInformation"
QT_MOC_LITERAL(15, 254, 50), // "QDBusPendingReply<QString,QSt..."
QT_MOC_LITERAL(16, 305, 19), // "QDBusReply<QString>"
QT_MOC_LITERAL(17, 325, 8), // "QString&"
QT_MOC_LITERAL(18, 334, 4), // "name"
QT_MOC_LITERAL(19, 339, 6), // "vendor"
QT_MOC_LITERAL(20, 346, 7), // "version"
QT_MOC_LITERAL(21, 354, 6), // "Notify"
QT_MOC_LITERAL(22, 361, 23), // "QDBusPendingReply<uint>"
QT_MOC_LITERAL(23, 385, 11), // "replaces_id"
QT_MOC_LITERAL(24, 397, 8), // "app_icon"
QT_MOC_LITERAL(25, 406, 7), // "summary"
QT_MOC_LITERAL(26, 414, 4), // "body"
QT_MOC_LITERAL(27, 419, 7), // "actions"
QT_MOC_LITERAL(28, 427, 5), // "hints"
QT_MOC_LITERAL(29, 433, 14) // "expire_timeout"

    },
    "MNotificationManagerProxy\0ActionInvoked\0"
    "\0id\0action_key\0NotificationClosed\0"
    "reason\0CloseNotification\0QDBusPendingReply<>\0"
    "GetCapabilities\0QDBusPendingReply<QStringList>\0"
    "GetNotifications\0"
    "QDBusPendingReply<QList<MNotification> >\0"
    "app_name\0GetServerInformation\0"
    "QDBusPendingReply<QString,QString,QString,QString>\0"
    "QDBusReply<QString>\0QString&\0name\0"
    "vendor\0version\0Notify\0QDBusPendingReply<uint>\0"
    "replaces_id\0app_icon\0summary\0body\0"
    "actions\0hints\0expire_timeout"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MNotificationManagerProxy[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   54,    2, 0x06 /* Public */,
       5,    2,   59,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    1,   64,    2, 0x0a /* Public */,
       9,    0,   67,    2, 0x0a /* Public */,
      11,    1,   68,    2, 0x0a /* Public */,
      14,    0,   71,    2, 0x0a /* Public */,
      14,    3,   72,    2, 0x0a /* Public */,
      21,    8,   79,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::UInt, QMetaType::QString,    3,    4,
    QMetaType::Void, QMetaType::UInt, QMetaType::UInt,    3,    6,

 // slots: parameters
    0x80000000 | 8, QMetaType::UInt,    3,
    0x80000000 | 10,
    0x80000000 | 12, QMetaType::QString,   13,
    0x80000000 | 15,
    0x80000000 | 16, 0x80000000 | 17, 0x80000000 | 17, 0x80000000 | 17,   18,   19,   20,
    0x80000000 | 22, QMetaType::QString, QMetaType::UInt, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QStringList, QMetaType::QVariantHash, QMetaType::Int,   13,   23,   24,   25,   26,   27,   28,   29,

       0        // eod
};

void MNotificationManagerProxy::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MNotificationManagerProxy *_t = static_cast<MNotificationManagerProxy *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->ActionInvoked((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 1: _t->NotificationClosed((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< uint(*)>(_a[2]))); break;
        case 2: { QDBusPendingReply<> _r = _t->CloseNotification((*reinterpret_cast< uint(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QDBusPendingReply<>*>(_a[0]) = std::move(_r); }  break;
        case 3: { QDBusPendingReply<QStringList> _r = _t->GetCapabilities();
            if (_a[0]) *reinterpret_cast< QDBusPendingReply<QStringList>*>(_a[0]) = std::move(_r); }  break;
        case 4: { QDBusPendingReply<QList<MNotification> > _r = _t->GetNotifications((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QDBusPendingReply<QList<MNotification> >*>(_a[0]) = std::move(_r); }  break;
        case 5: { QDBusPendingReply<QString,QString,QString,QString> _r = _t->GetServerInformation();
            if (_a[0]) *reinterpret_cast< QDBusPendingReply<QString,QString,QString,QString>*>(_a[0]) = std::move(_r); }  break;
        case 6: { QDBusReply<QString> _r = _t->GetServerInformation((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< QDBusReply<QString>*>(_a[0]) = std::move(_r); }  break;
        case 7: { QDBusPendingReply<uint> _r = _t->Notify((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< uint(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3])),(*reinterpret_cast< const QString(*)>(_a[4])),(*reinterpret_cast< const QString(*)>(_a[5])),(*reinterpret_cast< const QStringList(*)>(_a[6])),(*reinterpret_cast< const QVariantHash(*)>(_a[7])),(*reinterpret_cast< int(*)>(_a[8])));
            if (_a[0]) *reinterpret_cast< QDBusPendingReply<uint>*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (MNotificationManagerProxy::*_t)(uint , const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MNotificationManagerProxy::ActionInvoked)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MNotificationManagerProxy::*_t)(uint , uint );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MNotificationManagerProxy::NotificationClosed)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject MNotificationManagerProxy::staticMetaObject = {
    { &QDBusAbstractInterface::staticMetaObject, qt_meta_stringdata_MNotificationManagerProxy.data,
      qt_meta_data_MNotificationManagerProxy,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MNotificationManagerProxy::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MNotificationManagerProxy::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MNotificationManagerProxy.stringdata0))
        return static_cast<void*>(this);
    return QDBusAbstractInterface::qt_metacast(_clname);
}

int MNotificationManagerProxy::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDBusAbstractInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void MNotificationManagerProxy::ActionInvoked(uint _t1, const QString & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MNotificationManagerProxy::NotificationClosed(uint _t1, uint _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
