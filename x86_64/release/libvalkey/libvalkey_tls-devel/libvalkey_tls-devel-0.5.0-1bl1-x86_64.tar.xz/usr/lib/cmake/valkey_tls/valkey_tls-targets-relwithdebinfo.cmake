#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "valkey::valkey_tls" for configuration "RelWithDebInfo"
set_property(TARGET valkey::valkey_tls APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(valkey::valkey_tls PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvalkey_tls.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "valkey::valkey"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygvalkey_tls-0.dll"
  )

list(APPEND _cmake_import_check_targets valkey::valkey_tls )
list(APPEND _cmake_import_check_files_for_valkey::valkey_tls "${_IMPORT_PREFIX}/lib/libvalkey_tls.dll.a" "${_IMPORT_PREFIX}/bin/cygvalkey_tls-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
