#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "valkey::valkey" for configuration "RelWithDebInfo"
set_property(TARGET valkey::valkey APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(valkey::valkey PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvalkey.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygvalkey-0.dll"
  )

list(APPEND _cmake_import_check_targets valkey::valkey )
list(APPEND _cmake_import_check_files_for_valkey::valkey "${_IMPORT_PREFIX}/lib/libvalkey.dll.a" "${_IMPORT_PREFIX}/bin/cygvalkey-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
