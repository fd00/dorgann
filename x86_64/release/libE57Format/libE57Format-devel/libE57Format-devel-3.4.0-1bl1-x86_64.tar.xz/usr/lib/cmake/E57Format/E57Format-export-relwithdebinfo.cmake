#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "E57Format" for configuration "RelWithDebInfo"
set_property(TARGET E57Format APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(E57Format PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libE57Format.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygE57Format-3.dll"
  )

list(APPEND _cmake_import_check_targets E57Format )
list(APPEND _cmake_import_check_files_for_E57Format "${_IMPORT_PREFIX}/lib/libE57Format.dll.a" "${_IMPORT_PREFIX}/bin/cygE57Format-3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
