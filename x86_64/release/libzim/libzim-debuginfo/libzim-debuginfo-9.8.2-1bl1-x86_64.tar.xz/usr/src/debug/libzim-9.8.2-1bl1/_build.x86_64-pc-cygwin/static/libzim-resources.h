//This file is automaically generated. Do not modify it.
#ifndef KIWIX_LIBZIM_RESOURCES_H
#define KIWIX_LIBZIM_RESOURCES_H

#include <string>
#include <stdexcept>

namespace RESOURCE {
    namespace stopwords {
extern const std::string af;
}
    namespace stopwords {
extern const std::string ar;
}
    namespace stopwords {
extern const std::string bg;
}
    namespace stopwords {
extern const std::string bn;
}
    namespace stopwords {
extern const std::string br;
}
    namespace stopwords {
extern const std::string ca;
}
    namespace stopwords {
extern const std::string cs;
}
    namespace stopwords {
extern const std::string da;
}
    namespace stopwords {
extern const std::string de;
}
    namespace stopwords {
extern const std::string el;
}
    namespace stopwords {
extern const std::string en;
}
    namespace stopwords {
extern const std::string eo;
}
    namespace stopwords {
extern const std::string es;
}
    namespace stopwords {
extern const std::string et;
}
    namespace stopwords {
extern const std::string eu;
}
    namespace stopwords {
extern const std::string fa;
}
    namespace stopwords {
extern const std::string fi;
}
    namespace stopwords {
extern const std::string fr;
}
    namespace stopwords {
extern const std::string ga;
}
    namespace stopwords {
extern const std::string gl;
}
    namespace stopwords {
extern const std::string gu;
}
    namespace stopwords {
extern const std::string ha;
}
    namespace stopwords {
extern const std::string he;
}
    namespace stopwords {
extern const std::string hi;
}
    namespace stopwords {
extern const std::string hr;
}
    namespace stopwords {
extern const std::string hu;
}
    namespace stopwords {
extern const std::string hy;
}
    namespace stopwords {
extern const std::string id;
}
    namespace stopwords {
extern const std::string it;
}
    namespace stopwords {
extern const std::string ja;
}
    namespace stopwords {
extern const std::string ko;
}
    namespace stopwords {
extern const std::string ku;
}
    namespace stopwords {
extern const std::string la;
}
    namespace stopwords {
extern const std::string lt;
}
    namespace stopwords {
extern const std::string lv;
}
    namespace stopwords {
extern const std::string mr;
}
    namespace stopwords {
extern const std::string ms;
}
    namespace stopwords {
extern const std::string nl;
}
    namespace stopwords {
extern const std::string no;
}
    namespace stopwords {
extern const std::string pl;
}
    namespace stopwords {
extern const std::string pt;
}
    namespace stopwords {
extern const std::string ro;
}
    namespace stopwords {
extern const std::string ru;
}
    namespace stopwords {
extern const std::string sk;
}
    namespace stopwords {
extern const std::string sl;
}
    namespace stopwords {
extern const std::string so;
}
    namespace stopwords {
extern const std::string st;
}
    namespace stopwords {
extern const std::string sv;
}
    namespace stopwords {
extern const std::string sw;
}
    namespace stopwords {
extern const std::string th;
}
    namespace stopwords {
extern const std::string tl;
}
    namespace stopwords {
extern const std::string tr;
}
    namespace stopwords {
extern const std::string uk;
}
    namespace stopwords {
extern const std::string ur;
}
    namespace stopwords {
extern const std::string vi;
}
    namespace stopwords {
extern const std::string yo;
}
    namespace stopwords {
extern const std::string zh;
}
    namespace stopwords {
extern const std::string zu;
}
};

class ResourceNotFound : public std::runtime_error {
  public:
    ResourceNotFound(const std::string& what_arg):
      std::runtime_error(what_arg)
    { };
};

const std::string& getResource_libzim_resources_h(const std::string& name);

#define getResource(a) (getResource_libzim_resources_h(a))

#endif // KIWIX_LIBZIM_RESOURCES_H

