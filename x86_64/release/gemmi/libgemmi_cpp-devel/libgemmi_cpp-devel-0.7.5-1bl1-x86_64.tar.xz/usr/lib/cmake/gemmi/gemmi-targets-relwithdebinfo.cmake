#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "gemmi::prog" for configuration "RelWithDebInfo"
set_property(TARGET gemmi::prog APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(gemmi::prog PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/gemmi.exe"
  )

list(APPEND _cmake_import_check_targets gemmi::prog )
list(APPEND _cmake_import_check_files_for_gemmi::prog "${_IMPORT_PREFIX}/bin/gemmi.exe" )

# Import target "gemmi::gemmi_cpp" for configuration "RelWithDebInfo"
set_property(TARGET gemmi::gemmi_cpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(gemmi::gemmi_cpp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libgemmi_cpp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyggemmi_cpp-0.dll"
  )

list(APPEND _cmake_import_check_targets gemmi::gemmi_cpp )
list(APPEND _cmake_import_check_files_for_gemmi::gemmi_cpp "${_IMPORT_PREFIX}/lib/libgemmi_cpp.dll.a" "${_IMPORT_PREFIX}/bin/cyggemmi_cpp-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
